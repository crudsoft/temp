package com.itau.notification_manager.controller;

import com.itau.notification_manager.model.ClientNotificationCenter;
import com.itau.notification_manager.service.ClientNotificationCenterService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/notification_subscriptions")
public class ClientNotificationCenterController {

    private final ClientNotificationCenterService notificationCenterService;

    public ClientNotificationCenterController(ClientNotificationCenterService notificationCenterService) {
        this.notificationCenterService = notificationCenterService;
    }

    @GetMapping("/client/{clientId}")
    public ResponseEntity<ClientNotificationCenter> getClientNotificationCenter(@PathVariable Long clientId) {
        ClientNotificationCenter notificationCenter = notificationCenterService.getClientNotificationCenter(clientId);
        return ResponseEntity.ok(notificationCenter);
    }
}
