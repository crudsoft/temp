package com.itau.notification_manager.service;

import com.itau.notification_manager.model.ClientNotificationCenter;
import org.springframework.stereotype.Service;

@Service
public class ClientNotificationCenterService {

    private final NotificationSubscriptionService subscriptionService;

    public ClientNotificationCenterService(NotificationSubscriptionService subscriptionService) {
        this.subscriptionService = subscriptionService;
    }

    public ClientNotificationCenter getClientNotificationCenter(Long clientId) {
        return subscriptionService.getClientNotificationCenter(clientId);
    }
}
