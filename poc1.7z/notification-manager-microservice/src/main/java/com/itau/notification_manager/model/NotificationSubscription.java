package com.itau.notification_manager.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class NotificationSubscription {

    private Long id;
    private String notificationType; // Tipo de notificación (e.g., "Pago", "Transferencia")
    private List<SubscriptionPreferences> preferences; // Lista de preferencias de esta suscripción
}
