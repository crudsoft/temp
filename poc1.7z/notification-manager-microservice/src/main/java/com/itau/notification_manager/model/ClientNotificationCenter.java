package com.itau.notification_manager.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class ClientNotificationCenter {
    private Long clientId;
    private String cellPhone;
    private String email;
    private List<NotificationSubscription> subscriptions; // Lista de suscripciones
}
