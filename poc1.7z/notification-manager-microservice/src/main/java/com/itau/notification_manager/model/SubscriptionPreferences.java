package com.itau.notification_manager.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor

public class SubscriptionPreferences {
    private Long id;
    private Long subscriptionId; // Referencia a la suscripción
    private String channel; // Nombre del canal (e.g., "SMS", "Email", "Push")
    private boolean enabled; // Estado del canal (habilitado o deshabilitado)
}

