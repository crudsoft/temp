package com.itau.notification_manager.service;

import com.itau.notification_manager.model.ClientNotificationCenter;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.stereotype.Service;

import java.io.InputStream;
import java.util.List;
import java.util.Optional;

@Service
public class NotificationSubscriptionService {

    private List<ClientNotificationCenter> notificationCenters;

    public NotificationSubscriptionService() {
        loadNotificationCenters();
    }

    private void loadNotificationCenters() {
        try {
            ObjectMapper mapper = new ObjectMapper();
            TypeReference<List<ClientNotificationCenter>> typeReference = new TypeReference<>() {};
            InputStream inputStream = getClass().getResourceAsStream("/subscriptions.json");
            this.notificationCenters = mapper.readValue(inputStream, typeReference);
        } catch (Exception e) {
            throw new RuntimeException("Error loading client notification centers from JSON", e);
        }
    }

    public List<ClientNotificationCenter> getAllNotificationCenters() {
        return notificationCenters;
    }

    public ClientNotificationCenter getClientNotificationCenter(Long clientId) {
        Optional<ClientNotificationCenter> notificationCenter = notificationCenters.stream()
                .filter(center -> center.getClientId().equals(clientId))
                .findFirst();
        return notificationCenter.orElse(null);
    }
}
