import { Component, inject, OnInit, TemplateRef, ViewEncapsulation } from '@angular/core';
import { ClientNotificationCenter } from '../../model/client-notification-center.model';
import { NotificationCenterService } from '../../service/notification-center.service';
import { NotificationSubscription } from '../../model/notification-subscription.model';


@Component({
  selector: 'app-notification-manager',
  templateUrl: './notification-manager.component.html',
  styleUrls: [
    './notification-manager.component.scss',
    '../../../assets/styles/variables.css',            // Variables de estilos
    '../../../assets/styles/style-transferencias.css', // Estilos específicos
  ],
  encapsulation: ViewEncapsulation.ShadowDom
})
export class NotificationManagerComponent implements OnInit {

  clientNotificationCenter: ClientNotificationCenter | undefined;

  constructor(
    private notificationCenterService: NotificationCenterService,
  ) { }

  ngOnInit(): void {
    const clientId = 12345;  // Aquí podrías obtener el ID del cliente de alguna otra manera
    this.notificationCenterService.getClientNotificationCenter(clientId)
      .subscribe(data => this.clientNotificationCenter = data);
  }
}
