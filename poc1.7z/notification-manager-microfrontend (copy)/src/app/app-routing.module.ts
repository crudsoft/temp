import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { NotificationManagerComponent } from './component/notification-manager/notification-manager.component';

const routes: Routes = [
  { path: '', redirectTo: '/notification-manager', pathMatch: 'full' },
  { path: 'notification-manager', component: NotificationManagerComponent }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
