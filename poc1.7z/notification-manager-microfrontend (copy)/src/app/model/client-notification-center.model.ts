import { NotificationSubscription } from './notification-subscription.model';

export interface ClientNotificationCenter {
  clientId: number;
  cellPhone: string;
  email: string;
  subscriptions: NotificationSubscription[];  // Lista de suscripciones
}
