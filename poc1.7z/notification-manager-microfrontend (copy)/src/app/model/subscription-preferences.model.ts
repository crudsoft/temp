export interface SubscriptionPreferences {
  id: number;
  subscriptionId: number;
  channel: string;  // e.g., "SMS", "Email", "Push"
  enabled: boolean;
}
