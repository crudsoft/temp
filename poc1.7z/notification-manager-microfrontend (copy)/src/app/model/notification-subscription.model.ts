import { SubscriptionPreferences } from './subscription-preferences.model';

export interface NotificationSubscription {
  id: number;
  clientId: number;  // Referencia al Cliente
  notificationType: string;  // e.g., "Pago", "Transferencia"
  preferences: SubscriptionPreferences[];  // Lista de preferencias de esta suscripción
}
