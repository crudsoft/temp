import { Injector, NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { createCustomElement } from '@angular/elements';
import { AppComponent } from './app.component';
import { HttpClientModule } from '@angular/common/http';
import { AppRoutingModule } from './app-routing.module';
import { RouterModule } from '@angular/router';
import { NotificationManagerComponent } from './component/notification-manager/notification-manager.component';
import { FormsModule } from '@angular/forms';

@NgModule({
  declarations: [
    AppComponent,
    NotificationManagerComponent
  ],
  imports: [
    FormsModule,
    BrowserModule,
    HttpClientModule,
    AppRoutingModule,
    RouterModule.forRoot([],{ useHash: true }),
  ],
  providers: [],
  bootstrap: [],
})
export class AppModule {
  constructor(private injector: Injector) {
    // Crear un elemento personalizado
    const el = createCustomElement(NotificationManagerComponent, { injector });
    customElements.define('notification_manager-list-element', el);  // Define el nombre del elemento
  }

  ngDoBootstrap() {}  // Usar ngDoBootstrap en lugar de bootstraping un componente
}

