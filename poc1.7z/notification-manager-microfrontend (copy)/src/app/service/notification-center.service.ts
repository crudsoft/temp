import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { ClientNotificationCenter } from '../model/client-notification-center.model';

@Injectable({
  providedIn: 'root'
})
export class NotificationCenterService {

  private apiUrl = 'http://localhost:8080/api/notification_subscriptions/client';  // Ajusta la URL según tu backend

  constructor(private http: HttpClient) { }

  getClientNotificationCenter(clientId: number): Observable<ClientNotificationCenter> {
    return this.http.get<ClientNotificationCenter>(`${this.apiUrl}/${clientId}`);
  }
}
